#version 430 core

in vec3 position;

void main()
{
    vec3 flip_pos = vec3(-position.x, -position.y, position.z);
    gl_Position = vec4(flip_pos, 1.0f);
}